/**
 *
 * @author abg5406
 */
public class CourseName
{
    private String major;
    private String number;
    private String complement;

    public CourseName(String major, String number, String complement)
    {
        this.major = major;
        //this.setMajor(major);
        this.number = number;
        this.complement = complement;
    }
    
    public CourseName()
    {
        this.major = "IST";
        this.number = "000";
        this.complement = "?";
    }

    @Override
    public String toString()
    {
        return "CourseName{" + "major=" + major + ", number=" + number + ", complement=" + complement + '}';
    }

    public String getMajor()
    {
        return major;
    }

    public void setMajor(String major)
    {
        String m = major.toUpperCase().trim();
        
        if(this.major.matches("CMPSC"))
        {
            this.major = m;
            System.out.println(); 
        } 
        else
        {
            this.major = "IST";
        }
    }

    public String getNumber()
    {
        return number;
    }

    public void setNumber(String number)
    {
        String n = number;
        this.number = n;
    }

    public String getComplement()
    {
        return complement;
    }

    public void setComplement(String complement)
    {
        this.complement = complement;
    }
    
    
}
